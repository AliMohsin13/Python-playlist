from flask import Flask, render_template, request, redirect, url_for

app = Flask(__name__, template_folder='templates')

# Temporary storage for user credentials
user_credentials = {}


@app.route('/')
def home():
    return render_template('index.html')


@app.route('/signup', methods=['GET', 'POST'])
def signup():
    success_message = None

    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        user_credentials[username] = password
        success_message = f'Successfully signed up as {username}!'
       
    return render_template('signup.html', success_message=success_message)



@app.route('/login', methods=['GET', 'POST'])
def login():
    error_message = None

    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        if username in user_credentials and user_credentials[username] == password:
            return render_template('login_success.html', username=username)
        else:
            error_message = 'Invalid credentials. Please try again or sign up.'

    return render_template('login.html', error_message=error_message)


if __name__ == '__main__':
    app.run(debug=True)
